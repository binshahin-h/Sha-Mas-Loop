# Sha'Mas Loop

**Sha'Mas Loop** — a minimal, dependency-light implementation of the agent tool-calling loop — the
pattern behind Claude Code, AutoGPT-style bots, and most modern "AI agents."
Same loop, three languages, four LLM backends.

Full write-up: **[Building a Looping Agent That Works With Claude, OpenAI, and
Local Models](https://YOUR_BLOG_URL/posts/agent-loop-for-any-llm/)**

## Supported backends

| Provider   | Wire format              | Key needed             |
|------------|---------------------------|-------------------------|
| Claude     | Anthropic Messages API    | `ANTHROPIC_API_KEY`    |
| OpenAI     | Chat Completions API      | `OPENAI_API_KEY`       |
| OpenRouter | Chat Completions API      | `OPENROUTER_API_KEY`   |
| Ollama     | Chat Completions API      | none (local server)    |

OpenAI, OpenRouter, and Ollama all speak the same `/chat/completions` + `tools`
shape, so one adapter (`OpenAICompatProvider`) serves all three. Claude gets
its own adapter for its `tool_use` / `tool_result` block format. The loop
itself never changes.

## Quick start

```bash
# Python (3.9+, stdlib only)
cd python
ANTHROPIC_API_KEY=sk-ant-... python agent_loop.py --provider claude "What's 42*17, then the time?"

# Node.js (18+, built-in fetch)
cd node
ANTHROPIC_API_KEY=sk-ant-... node agent-loop.js claude "What's 42*17, then the time?"

# PHP (8+, curl extension)
cd php
ANTHROPIC_API_KEY=sk-ant-... php agent_loop.php claude "What's 42*17, then the time?"
```

Swap `claude` for `openai`, `openrouter <model>`, or `ollama <model>` to hit a
different backend with the identical CLI shape. See `docs/agent-loop-docs.html`
for the full reference (environment variables, architecture, extending it,
troubleshooting).

## What's in the box

Two demo tools, kept intentionally boring so the interesting part stays the
loop, not the tools:

- `calculate(expression)` — regex-validated arithmetic
- `get_current_time()` — returns current UTC time

Real usage: swap these for whatever your agent actually needs — a database
query, a PDF generator, a web search — the loop doesn't care what a tool
*does*, only that it returns JSON-serializable data.

## This is a teaching example, not production code

Before trusting this with anything real, add: a hard cap on `max_turns`,
sandboxed tool execution, retries on transient API errors, tool-call logging,
and per-turn cost tracking. Details in the docs.

## License

MIT — see [LICENSE](./LICENSE).
