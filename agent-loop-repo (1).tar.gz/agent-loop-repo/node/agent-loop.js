/**
 * Sha'Mas Loop — a minimal multi-provider agent loop (Node 18+, built-in fetch, zero deps).
 *
 * Supports: claude | openai | openrouter | ollama
 *
 * Usage:
 *   ANTHROPIC_API_KEY=... node agent-loop.js claude "What's 42*17, then the time?"
 *   OPENAI_API_KEY=...    node agent-loop.js openai "..."
 *   OPENROUTER_API_KEY=... node agent-loop.js openrouter meta-llama/llama-3.1-8b-instruct "..."
 *                          node agent-loop.js ollama llama3.1 "..."   (local, no key needed)
 */

// ---------------------------------------------------------------------------
// 1. Tools
// ---------------------------------------------------------------------------

function safeEval(expr) {
  if (!/^[\d\s+\-*/().]+$/.test(expr)) throw new Error("invalid expression");
  // eslint-disable-next-line no-eval
  return eval(expr);
}

const TOOLS = {
  calculate: ({ expression }) => {
    try {
      return { result: safeEval(expression) };
    } catch (e) {
      return { error: e.message };
    }
  },
  get_current_time: () => ({ time_utc: new Date().toISOString(), note: "always UTC in this demo" }),
};

const TOOL_SCHEMAS = [
  {
    name: "calculate",
    description: "Evaluate a basic arithmetic expression, e.g. '12 * (3 + 4)'.",
    parameters: { type: "object", properties: { expression: { type: "string" } }, required: ["expression"] },
  },
  {
    name: "get_current_time",
    description: "Get the current UTC time.",
    parameters: { type: "object", properties: { timezone_name: { type: "string" } }, required: [] },
  },
];

// ---------------------------------------------------------------------------
// 2. Provider adapters
// ---------------------------------------------------------------------------

class ClaudeProvider {
  constructor(model = "claude-sonnet-4-6") {
    this.model = model;
    this.apiKey = process.env.ANTHROPIC_API_KEY;
    this.tools = TOOL_SCHEMAS.map((t) => ({ name: t.name, description: t.description, input_schema: t.parameters }));
  }

  async chat(messages) {
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "x-api-key": this.apiKey,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
      },
      body: JSON.stringify({ model: this.model, max_tokens: 1024, messages, tools: this.tools }),
    });
    const data = await res.json();

    const toolCalls = [];
    let text = [];
    for (const block of data.content) {
      if (block.type === "text") text.push(block.text);
      if (block.type === "tool_use") toolCalls.push({ id: block.id, name: block.name, arguments: block.input });
    }

    return {
      content: text.join("\n") || null,
      toolCalls,
      rawAssistantMessage: { role: "assistant", content: data.content },
    };
  }

  toolResultMessage(id, result) {
    return { role: "user", content: [{ type: "tool_result", tool_use_id: id, content: JSON.stringify(result) }] };
  }
}

class OpenAICompatProvider {
  constructor(model, baseUrl, apiKey = null) {
    this.model = model;
    this.baseUrl = baseUrl.replace(/\/$/, "");
    this.apiKey = apiKey;
    this.tools = TOOL_SCHEMAS.map((t) => ({ type: "function", function: { name: t.name, description: t.description, parameters: t.parameters } }));
  }

  async chat(messages) {
    const headers = { "content-type": "application/json" };
    if (this.apiKey) headers.Authorization = `Bearer ${this.apiKey}`;

    const res = await fetch(`${this.baseUrl}/chat/completions`, {
      method: "POST",
      headers,
      body: JSON.stringify({ model: this.model, messages, tools: this.tools }),
    });
    const data = await res.json();
    const msg = data.choices[0].message;

    const toolCalls = (msg.tool_calls || []).map((tc) => ({
      id: tc.id,
      name: tc.function.name,
      arguments: JSON.parse(tc.function.arguments),
    }));

    return { content: msg.content, toolCalls, rawAssistantMessage: msg };
  }

  toolResultMessage(id, result) {
    return { role: "tool", tool_call_id: id, content: JSON.stringify(result) };
  }
}

function buildProvider(name, model) {
  switch (name) {
    case "claude":
      return new ClaudeProvider(model || "claude-sonnet-4-6");
    case "openai":
      return new OpenAICompatProvider(model || "gpt-4o", "https://api.openai.com/v1", process.env.OPENAI_API_KEY);
    case "openrouter":
      return new OpenAICompatProvider(model || "meta-llama/llama-3.1-8b-instruct", "https://openrouter.ai/api/v1", process.env.OPENROUTER_API_KEY);
    case "ollama":
      return new OpenAICompatProvider(model || "llama3.1", "http://localhost:11434/v1");
    default:
      throw new Error(`unknown provider ${name}`);
  }
}

// ---------------------------------------------------------------------------
// 3. The loop — identical regardless of provider
// ---------------------------------------------------------------------------

async function runAgent(provider, userMessage, maxTurns = 8) {
  const messages = [{ role: "user", content: userMessage }];

  for (let turn = 0; turn < maxTurns; turn++) {
    const result = await provider.chat(messages);

    if (result.toolCalls.length > 0) {
      messages.push(result.rawAssistantMessage);
      for (const call of result.toolCalls) {
        console.log(`  [tool call] ${call.name}(${JSON.stringify(call.arguments)})`);
        const fn = TOOLS[call.name];
        const toolResult = fn ? fn(call.arguments) : { error: "unknown tool" };
        messages.push(provider.toolResultMessage(call.id, toolResult));
      }
      continue;
    }

    return result.content;
  }

  return "[stopped: max_turns reached without a final answer]";
}

// ---------------------------------------------------------------------------
// CLI
// ---------------------------------------------------------------------------

const [providerName, ...rest] = process.argv.slice(2);
let model = null;
let prompt = rest.join(" ");
// allow: node agent-loop.js openrouter <model> <prompt...>
if (providerName === "openrouter" || providerName === "ollama") {
  [model, ...rest] = rest;
  prompt = rest.join(" ");
}

console.log("Sha'Mas Loop\n");
const provider = buildProvider(providerName, model);
runAgent(provider, prompt).then((answer) => console.log("\n" + answer));
