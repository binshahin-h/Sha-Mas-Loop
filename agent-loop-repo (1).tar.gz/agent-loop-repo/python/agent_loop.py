"""
Sha'Mas Loop — a minimal multi-provider agent loop.

Supports:
  - Anthropic (Claude)          -> native Messages API
  - OpenAI                      -> Chat Completions API
  - OpenRouter / Ollama         -> same Chat Completions API, different base_url

The loop logic (run_agent) is provider-agnostic. Only the wire format
(how tools/tool-calls/tool-results are shaped) differs between Claude
and everything OpenAI-compatible.

Usage:
    export ANTHROPIC_API_KEY=...      # for --provider claude
    export OPENAI_API_KEY=...         # for --provider openai
    export OPENROUTER_API_KEY=...     # for --provider openrouter
    # Ollama needs no key, just a local server: `ollama serve`

    python agent_loop.py --provider claude   "What's 42 * 17, then tell me the time?"
    python agent_loop.py --provider openai   "..."
    python agent_loop.py --provider openrouter --model meta-llama/llama-3.1-8b-instruct "..."
    python agent_loop.py --provider ollama --model llama3.1 "..."
"""

import argparse
import ast
import json
import operator
import os
import urllib.request
from datetime import datetime, timezone


# ---------------------------------------------------------------------------
# 1. Tools the agent is allowed to call
# ---------------------------------------------------------------------------

_OPS = {
    ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
    ast.Div: operator.truediv, ast.Pow: operator.pow,
    ast.USub: operator.neg, ast.Mod: operator.mod,
}


def _safe_eval(expr: str):
    def ev(node):
        if isinstance(node, ast.Expression):
            return ev(node.body)
        if isinstance(node, ast.Constant):
            return node.value
        if isinstance(node, ast.BinOp):
            return _OPS[type(node.op)](ev(node.left), ev(node.right))
        if isinstance(node, ast.UnaryOp):
            return _OPS[type(node.op)](ev(node.operand))
        raise ValueError("unsupported expression")
    return ev(ast.parse(expr, mode="eval"))


def tool_calculate(expression, **_):
    try:
        return {"result": _safe_eval(expression)}
    except Exception as e:
        return {"error": str(e)}


def tool_get_current_time(timezone_name="UTC", **_):
    return {"time_utc": datetime.now(timezone.utc).isoformat(), "note": "always UTC in this demo"}


TOOLS = {
    "calculate": tool_calculate,
    "get_current_time": tool_get_current_time,
}

# provider-neutral schema; each provider adapter converts this to its own shape
TOOL_SCHEMAS = [
    {
        "name": "calculate",
        "description": "Evaluate a basic arithmetic expression, e.g. '12 * (3 + 4)'.",
        "parameters": {
            "type": "object",
            "properties": {"expression": {"type": "string"}},
            "required": ["expression"],
        },
    },
    {
        "name": "get_current_time",
        "description": "Get the current UTC time.",
        "parameters": {
            "type": "object",
            "properties": {"timezone_name": {"type": "string"}},
            "required": [],
        },
    },
]


def _post_json(url, headers, body):
    req = urllib.request.Request(
        url, data=json.dumps(body).encode(), headers=headers, method="POST"
    )
    with urllib.request.urlopen(req) as resp:
        return json.loads(resp.read())


# ---------------------------------------------------------------------------
# 2. Provider adapters
#    Each adapter exposes: .chat(messages) -> dict with
#       content: str | None                (final text, if any)
#       tool_calls: list[{id, name, arguments}]
#       raw_assistant_message: <provider-native message to append to history>
#    and .tool_result_message(id, result) -> <provider-native message>
# ---------------------------------------------------------------------------

class ClaudeProvider:
    def __init__(self, model="claude-sonnet-4-6"):
        self.model = model
        self.api_key = os.environ["ANTHROPIC_API_KEY"]
        self.tools = [
            {"name": t["name"], "description": t["description"], "input_schema": t["parameters"]}
            for t in TOOL_SCHEMAS
        ]

    def chat(self, messages):
        body = {
            "model": self.model,
            "max_tokens": 1024,
            "messages": messages,
            "tools": self.tools,
        }
        headers = {
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        }
        resp = _post_json("https://api.anthropic.com/v1/messages", headers, body)

        tool_calls, text_parts = [], []
        for block in resp["content"]:
            if block["type"] == "text":
                text_parts.append(block["text"])
            elif block["type"] == "tool_use":
                tool_calls.append({"id": block["id"], "name": block["name"], "arguments": block["input"]})

        return {
            "content": "\n".join(text_parts) or None,
            "tool_calls": tool_calls,
            "raw_assistant_message": {"role": "assistant", "content": resp["content"]},
        }

    def tool_result_message(self, tool_call_id, result):
        return {
            "role": "user",
            "content": [{"type": "tool_result", "tool_use_id": tool_call_id, "content": json.dumps(result)}],
        }


class OpenAICompatProvider:
    """Works for OpenAI, OpenRouter, and Ollama — all speak the same
    /chat/completions + tools shape. Only base_url / key / model differ."""

    def __init__(self, model, base_url, api_key=None, extra_headers=None):
        self.model = model
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.extra_headers = extra_headers or {}
        self.tools = [
            {"type": "function", "function": {"name": t["name"], "description": t["description"], "parameters": t["parameters"]}}
            for t in TOOL_SCHEMAS
        ]

    def chat(self, messages):
        body = {"model": self.model, "messages": messages, "tools": self.tools}
        headers = {"content-type": "application/json", **self.extra_headers}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        resp = _post_json(f"{self.base_url}/chat/completions", headers, body)

        msg = resp["choices"][0]["message"]
        tool_calls = []
        for tc in msg.get("tool_calls") or []:
            tool_calls.append({
                "id": tc["id"],
                "name": tc["function"]["name"],
                "arguments": json.loads(tc["function"]["arguments"]),
            })

        return {
            "content": msg.get("content"),
            "tool_calls": tool_calls,
            "raw_assistant_message": msg,
        }

    def tool_result_message(self, tool_call_id, result):
        return {"role": "tool", "tool_call_id": tool_call_id, "content": json.dumps(result)}


def build_provider(name, model=None):
    if name == "claude":
        return ClaudeProvider(model=model or "claude-sonnet-4-6")
    if name == "openai":
        return OpenAICompatProvider(model=model or "gpt-4o", base_url="https://api.openai.com/v1",
                                     api_key=os.environ["OPENAI_API_KEY"])
    if name == "openrouter":
        return OpenAICompatProvider(model=model or "meta-llama/llama-3.1-8b-instruct",
                                     base_url="https://openrouter.ai/api/v1",
                                     api_key=os.environ["OPENROUTER_API_KEY"])
    if name == "ollama":
        return OpenAICompatProvider(model=model or "llama3.1", base_url="http://localhost:11434/v1")
    raise ValueError(f"unknown provider {name}")


# ---------------------------------------------------------------------------
# 3. The loop itself — identical regardless of provider
# ---------------------------------------------------------------------------

def run_agent(provider, user_message, max_turns=8, verbose=True):
    messages = [{"role": "user", "content": user_message}]

    for turn in range(max_turns):
        result = provider.chat(messages)

        if result["tool_calls"]:
            messages.append(result["raw_assistant_message"])
            for call in result["tool_calls"]:
                if verbose:
                    print(f"  [tool call] {call['name']}({call['arguments']})")
                fn = TOOLS.get(call["name"])
                tool_result = fn(**call["arguments"]) if fn else {"error": "unknown tool"}
                messages.append(provider.tool_result_message(call["id"], tool_result))
            continue  # let the model see the tool results and respond again

        return result["content"]

    return "[stopped: max_turns reached without a final answer]"


if __name__ == "__main__":
    print("Sha'Mas Loop\n")
    parser = argparse.ArgumentParser()
    parser.add_argument("--provider", choices=["claude", "openai", "openrouter", "ollama"], default="claude")
    parser.add_argument("--model", default=None)
    parser.add_argument("prompt")
    args = parser.parse_args()

    provider = build_provider(args.provider, args.model)
    answer = run_agent(provider, args.prompt)
    print("\n" + answer)
