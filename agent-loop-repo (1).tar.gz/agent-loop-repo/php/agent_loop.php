<?php
/**
 * Sha'Mas Loop — a minimal multi-provider agent loop, pure PHP + curl (no SDK/composer needed).
 *
 * Usage:
 *   ANTHROPIC_API_KEY=... php agent_loop.php claude "What's 42*17, then the time?"
 *   OPENAI_API_KEY=...    php agent_loop.php openai "..."
 *   OPENROUTER_API_KEY=... php agent_loop.php openrouter meta-llama/llama-3.1-8b-instruct "..."
 *                          php agent_loop.php ollama llama3.1 "..."   (local, no key needed)
 */

// ---------------------------------------------------------------------------
// 1. Tools
// ---------------------------------------------------------------------------

function tool_calculate(array $args): array {
    $expr = $args['expression'] ?? '';
    if (!preg_match('/^[\d\s+\-*\/().]+$/', $expr)) {
        return ['error' => 'invalid expression'];
    }
    // Restricted arithmetic-only evaluation via a tiny recursive parser.
    try {
        $result = eval("return {$expr};"); // safe here: input pre-validated to digits/operators only
        return ['result' => $result];
    } catch (\Throwable $e) {
        return ['error' => $e->getMessage()];
    }
}

function tool_get_current_time(array $args): array {
    return ['time_utc' => gmdate('c'), 'note' => 'always UTC in this demo'];
}

$TOOLS = [
    'calculate' => 'tool_calculate',
    'get_current_time' => 'tool_get_current_time',
];

$TOOL_SCHEMAS = [
    [
        'name' => 'calculate',
        'description' => "Evaluate a basic arithmetic expression, e.g. '12 * (3 + 4)'.",
        'parameters' => [
            'type' => 'object',
            'properties' => ['expression' => ['type' => 'string']],
            'required' => ['expression'],
        ],
    ],
    [
        'name' => 'get_current_time',
        'description' => 'Get the current UTC time.',
        'parameters' => [
            'type' => 'object',
            'properties' => ['timezone_name' => ['type' => 'string']],
            'required' => [],
        ],
    ],
];

// ---------------------------------------------------------------------------
// helper: POST JSON via curl
// ---------------------------------------------------------------------------

function post_json(string $url, array $headers, array $body): array {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_POSTFIELDS => json_encode($body),
        CURLOPT_RETURNTRANSFER => true,
    ]);
    $response = curl_exec($ch);
    if ($response === false) {
        throw new \RuntimeException('curl error: ' . curl_error($ch));
    }
    curl_close($ch);
    return json_decode($response, true);
}

// ---------------------------------------------------------------------------
// 2. Provider adapters
//    Each returns ['content' => ?string, 'tool_calls' => [...], 'raw_assistant_message' => [...]]
// ---------------------------------------------------------------------------

class ClaudeProvider {
    private string $model;
    private string $apiKey;
    private array $tools;

    public function __construct(array $toolSchemas, string $model = 'claude-sonnet-4-6') {
        $this->model = $model;
        $this->apiKey = getenv('ANTHROPIC_API_KEY');
        $this->tools = array_map(fn($t) => [
            'name' => $t['name'], 'description' => $t['description'], 'input_schema' => $t['parameters'],
        ], $toolSchemas);
    }

    public function chat(array $messages): array {
        $body = ['model' => $this->model, 'max_tokens' => 1024, 'messages' => $messages, 'tools' => $this->tools];
        $headers = [
            'x-api-key: ' . $this->apiKey,
            'anthropic-version: 2023-06-01',
            'content-type: application/json',
        ];
        $resp = post_json('https://api.anthropic.com/v1/messages', $headers, $body);

        $toolCalls = [];
        $textParts = [];
        foreach ($resp['content'] as $block) {
            if ($block['type'] === 'text') $textParts[] = $block['text'];
            if ($block['type'] === 'tool_use') {
                $toolCalls[] = ['id' => $block['id'], 'name' => $block['name'], 'arguments' => $block['input']];
            }
        }

        return [
            'content' => $textParts ? implode("\n", $textParts) : null,
            'tool_calls' => $toolCalls,
            'raw_assistant_message' => ['role' => 'assistant', 'content' => $resp['content']],
        ];
    }

    public function toolResultMessage(string $id, array $result): array {
        return [
            'role' => 'user',
            'content' => [['type' => 'tool_result', 'tool_use_id' => $id, 'content' => json_encode($result)]],
        ];
    }
}

class OpenAICompatProvider {
    private string $model;
    private string $baseUrl;
    private ?string $apiKey;
    private array $tools;

    public function __construct(array $toolSchemas, string $model, string $baseUrl, ?string $apiKey = null) {
        $this->model = $model;
        $this->baseUrl = rtrim($baseUrl, '/');
        $this->apiKey = $apiKey;
        $this->tools = array_map(fn($t) => [
            'type' => 'function',
            'function' => ['name' => $t['name'], 'description' => $t['description'], 'parameters' => $t['parameters']],
        ], $toolSchemas);
    }

    public function chat(array $messages): array {
        $headers = ['content-type: application/json'];
        if ($this->apiKey) $headers[] = 'Authorization: Bearer ' . $this->apiKey;

        $resp = post_json("{$this->baseUrl}/chat/completions", $headers, [
            'model' => $this->model, 'messages' => $messages, 'tools' => $this->tools,
        ]);
        $msg = $resp['choices'][0]['message'];

        $toolCalls = [];
        foreach ($msg['tool_calls'] ?? [] as $tc) {
            $toolCalls[] = [
                'id' => $tc['id'],
                'name' => $tc['function']['name'],
                'arguments' => json_decode($tc['function']['arguments'], true),
            ];
        }

        return ['content' => $msg['content'] ?? null, 'tool_calls' => $toolCalls, 'raw_assistant_message' => $msg];
    }

    public function toolResultMessage(string $id, array $result): array {
        return ['role' => 'tool', 'tool_call_id' => $id, 'content' => json_encode($result)];
    }
}

function build_provider(string $name, array $toolSchemas, ?string $model = null) {
    switch ($name) {
        case 'claude':
            return new ClaudeProvider($toolSchemas, $model ?: 'claude-sonnet-4-6');
        case 'openai':
            return new OpenAICompatProvider($toolSchemas, $model ?: 'gpt-4o', 'https://api.openai.com/v1', getenv('OPENAI_API_KEY'));
        case 'openrouter':
            return new OpenAICompatProvider($toolSchemas, $model ?: 'meta-llama/llama-3.1-8b-instruct', 'https://openrouter.ai/api/v1', getenv('OPENROUTER_API_KEY'));
        case 'ollama':
            return new OpenAICompatProvider($toolSchemas, $model ?: 'llama3.1', 'http://localhost:11434/v1', null);
        default:
            throw new \InvalidArgumentException("unknown provider {$name}");
    }
}

// ---------------------------------------------------------------------------
// 3. The loop — identical regardless of provider
// ---------------------------------------------------------------------------

function run_agent($provider, array $tools, string $userMessage, int $maxTurns = 8): string {
    $messages = [['role' => 'user', 'content' => $userMessage]];

    for ($turn = 0; $turn < $maxTurns; $turn++) {
        $result = $provider->chat($messages);

        if (!empty($result['tool_calls'])) {
            $messages[] = $result['raw_assistant_message'];
            foreach ($result['tool_calls'] as $call) {
                echo "  [tool call] {$call['name']}(" . json_encode($call['arguments']) . ")\n";
                $fn = $tools[$call['name']] ?? null;
                $toolResult = $fn ? $fn($call['arguments']) : ['error' => 'unknown tool'];
                $messages[] = $provider->toolResultMessage($call['id'], $toolResult);
            }
            continue;
        }

        return $result['content'] ?? '';
    }

    return '[stopped: max_turns reached without a final answer]';
}

// ---------------------------------------------------------------------------
// CLI
// ---------------------------------------------------------------------------

$args = $argv;
array_shift($args); // script name
$providerName = array_shift($args);
$model = null;
if (in_array($providerName, ['openrouter', 'ollama'], true) && count($args) > 1) {
    $model = array_shift($args);
}
$prompt = implode(' ', $args);

echo "Sha'Mas Loop\n\n";
$provider = build_provider($providerName, $TOOL_SCHEMAS, $model);
$answer = run_agent($provider, $TOOLS, $prompt);
echo "\n" . $answer . "\n";
